<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bai_viet extends Model
{
    //
    protected $table = "bai_viet";
    public $timestamps = false;
}
