<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class binh_luan_bai_viet extends Model
{
    protected $table = "binh_luan_bai_viet";
    public $timestamps = false;
}
