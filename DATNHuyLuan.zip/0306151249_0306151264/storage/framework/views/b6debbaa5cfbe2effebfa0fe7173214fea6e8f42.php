<?php $__env->startSection('main'); ?>
 <!-- body -->
    <div class="topnav contentmain  ">
<!-- ảnh bìa -->
<div id="anhbia">
</div>
<!-- end ảnh bìa -->
       <div class="leftnav" >
         <div id="thongtincuanhom"></div>
         <div id="thongtinkhaccuanhom"></div>
        </div>
        
<!--  -->
       
        <div id="divcontent" class="content"  >
          <div id="divdangbaiviet">
            <?php echo $__env->make('baiviet.dangbaiviet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
         </div>
         <div id="divnoidungcon">

            <!--  -->
           
          <?php for($i = 0; $i < count($lstbaiviet) ; $i++): ?>
               <?php echo $__env->make('baiviet.hienthibaiviet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endfor; ?>
          </div>
            <!--  -->
        </div>
        
<!--  -->
        <div class="rightnav">
        </div>

    </div>
    <!-- //// -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>