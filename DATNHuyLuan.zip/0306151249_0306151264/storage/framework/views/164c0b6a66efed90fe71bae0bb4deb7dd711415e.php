
<?php for($i = 0; $i <count($lstbinhluan) ; $i++): ?>
   

<div style="height: auto;width: 100%;">
                                <div id="dv-div-tare-cmt-<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>"  class="cl-div-content-boxreadcmt-avt" >
                                    <div class="cl-div-avt-cmt" >
                                        <img class="imgaccountcmt"  src=" <?php echo e(asset('pictures/avt1.jpg')); ?>" alt="Mountain View" >
                                    </div>
                                    <div class="cl-div-tare-read" >

                                        <div id="div-tare-cmt-<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>" style="width: 427px;float: left;height: 20px;padding-right: 5px;">
                                                <textarea disabled="true" id="tare-cmt-<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>" cols="53" name="foo"  class="tara-read-cmt" > Lu Lu: <?php echo e($lstbinhluan[$i]->noi_dung_binh_luan); ?></textarea>
                                        </div>
                                        <div class="div-btn-show-allcmt" id="div-id-show-all-cmt-<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>"  onclick='showfullcmt("<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>","<?php echo e($mabaivietl); ?>")'>      
                                                <i style="color: #9695d8;" id="i-btn-show-allcmt<?php echo e($lstbinhluan[$i]->ma_binh_luan); ?>" class="fa fa-arrow-circle-down stick-xemthem" aria-hidden="true"></i>
                                        </div>
                                        <div class="div-btn-like-cmt" >      
                                                <i style="color: #9695d8;" class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                                        </div>
                                        <div class="div-btn-rep-cmt" >      
                                                <i style="color: #9695d8;" class="fa fa-reply" aria-hidden="true"></i>
                                        </div>                                 
                                    </div>
                                </div>

            <div class="cl-divrepcmt" id="divrepcmt" style="margin-top: 5px;">
                                
                               
                                

                                
            </div>
</div>
<?php endfor; ?>