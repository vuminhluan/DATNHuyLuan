<?php $__env->startSection('NoiDung'); ?>
 <!-- body -->
    <div class="topnav contentmain  ">
<!-- ảnh bìa -->
<div id="anhbia">
</div>
<!-- end ảnh bìa -->
       <div class="leftnav" >
         <div id="thongtincuanhom"></div>
         <div id="thongtinkhaccuanhom"></div>
        </div>
        
<!--  -->
        <div class="content"  >
            <!--  -->
            <?php
            for ($i=0; $i < 1; $i++) { 
            	@include('includes.baiviet');
            }
             
            ?>
            <!--  -->
        </div>
        
<!--  -->
        <div class="rightnav">
        </div>

    </div>
    <!-- //// -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.baiviet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('includes.navtop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>