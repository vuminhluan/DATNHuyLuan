

<div style="margin-top: 400px; border-width: 1px 0 0px 0; border-style: solid; border-color:#999;height: 200px; line-height: 200px;background-color: #fff; text-align: center;width: 100%;bottom: 0;left: 0;"><p>Đây là footer | &copy; 2018</p></div>
