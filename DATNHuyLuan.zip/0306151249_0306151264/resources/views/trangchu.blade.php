@extends('master.masterpage')

@section('title')
	<title>Trang chủ</title>
@endsection

@section('css')
	{{-- <link rel="stylesheet" href="css/luan.css"> --}}
@endsection

@section('main')


	<h1 class="haha">
		Trang chủ
	</h1>
@endsection
