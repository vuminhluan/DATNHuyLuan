@extends('master.luan.trangcanhan_masterpage')

@section('title')
	<title>Trang cá nhân {{$username}}</title>
@endsection

@section('noidung_trangcanhan')
<div class="content">
	Bài viết ở đây (Theo tứ tự mới nhất -> cũ)
</div>



@endsection
