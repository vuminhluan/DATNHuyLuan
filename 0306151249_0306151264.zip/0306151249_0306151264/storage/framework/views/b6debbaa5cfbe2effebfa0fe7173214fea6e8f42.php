<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/lu/nhom/nhomcss.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/jslu/nhom/nhomjs.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
 <!-- body -->
    <div class="topnav contentmain  ">
<!-- ảnh bìa -->
<div id="anhbia">
</div>
<!-- end ảnh bìa -->
       <div class="leftnav" >
         <div id="thongtincuanhom">
           <div style="margin-top: 5px;margin-right: 5px;">
            <?php if($quyentruycapnhomcuataikhoan[0]->ma_chuc_vu=="CV01"): ?>
               <div id="div-btn-show-menu-setting-nhom" style="border: solid 1px #9695d8; cursor: pointer;width: 287px;height: 36px;float: right;padding: 5px;"><h3><i class="fa fa-envelope-o" aria-hidden="true"> &nbsp;Thông báo của quản lý nhóm</i></h3></div>
            <?php endif; ?>
            
           </div>
         </div>
         <div id="thongtinkhaccuanhom"></div>
        </div>
        
<!--  -->
       
        <div id="divcontent" class="content"  >
          <div id="divdangbaiviet">
            <?php echo $__env->make('baiviet.dangbaiviet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
         </div>
         <div id="divnoidungcon">

            <!--  -->
           
          <?php for($i = 0; $i < count($lstbaiviet) ; $i++): ?>
               <?php echo $__env->make('baiviet.hienthibaiviet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endfor; ?>
          </div>
            <!--  -->
        </div>
        
<!--  -->
        <div class="rightnav">
        </div>

    </div>
    
    <div id="div-setting-nhom-menu" class="modal-setting-nhom">
     
        <?php echo $__env->make('includes.content-setting-group-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     
    </div>
    <!-- //// -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>