
<head>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/lu/baiviet/noidungbaiviet.css')); ?>">
</head>
                
                

            <div class="subcontent" >
                <!--  -->
                 <div class="headtus" style=" height: 60px;  " >
                    <div class="divtopcontent" >
                      <img class="imgavtnguoidang" src=" <?php echo e(asset('pictures/avt1.jpg')); ?>" alt="Mountain View">
                    </div>
                    <div class="divtennguoidang" >
                      <span> <h3 class="spantennguoidang">  <?php echo e($lstbaiviet[$i]->ma_bai_viet); ?> </h3> </span><br>
                      <span> <h5 class="spanthoigiandang"> 22/02/2018 18:07 </h5> <span>
                    </div>
                 </div>
                 <!--  -->
                 <div class="bodytus" >
                    <div class="texttus" >
                        <span><h4><?php echo e($lstbaiviet[$i]->noi_dung_bai_viet); ?></h4></span>
                    </div>
                    <div class="divimagetus" >
                        <img class="imgtus" 
                       src=" <?php echo e(asset('pictures/avt1.jpg')); ?>" alt="Mountain View">
                    </div>

                 </div>
                 <?php echo $__env->make('binhluan.hienthibinhluan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                 
    </div>

            <!--  -->
