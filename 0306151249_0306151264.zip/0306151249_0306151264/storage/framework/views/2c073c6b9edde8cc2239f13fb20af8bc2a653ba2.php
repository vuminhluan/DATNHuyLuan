
            <div class="subcontent" >
                <!--  -->
                 <div class="headtus" style="background-color: rgb(118,223,236); " >
                    <div style="width: 40px; height:40px; margin-top: 5px; margin-left: 5px; float: left; " >
                      <img style="width: 40px; height: 40px; border-radius: 50%;"
                       src=" <?php echo e(asset('pictures/avt1.jpg')); ?>" alt="Mountain View">
                    </div>
                    <div style="float:left; margin-left:10px;">
                      <span> <h4 style="margin-top: 10px;margin-bottom:0px;">  <?php echo e($t); ?> </h4> </span><br>
                      <span> <h5 style="margin-top: -22px; color:#ccc"> 22/02/2018 18:07 </h5> <span>
                    </div>
                 </div>
                 <!--  -->
                 <div class="bodytus">

                 </div>
                 <!--  -->
                 <div class="foottus">

                 </div>
                 <!--  -->
                 <div class="commenttus">

                 </div>

            </div>
            <!--  -->
