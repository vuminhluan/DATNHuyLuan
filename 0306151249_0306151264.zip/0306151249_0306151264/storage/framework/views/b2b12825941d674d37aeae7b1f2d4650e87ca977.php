<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<?php echo $__env->yieldContent('title'); ?>
	
	<link rel='icon' href='favicon.ico' type='image/x-icon'/ >

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/includescss/navtopcss.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/lu/baiviet/baiviet.css')); ?>">
	
	<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	
	<script type="text/javascript" src="<?php echo e(asset('js/globaljs/varglobal.js')); ?>" charset="utf-8"></script>
	<script src="<?php echo e(asset('js/jquery/jquery3.3.1.js')); ?>" charset="utf-8"></script>
	

	<?php echo $__env->yieldContent('css'); ?>

</head>
<body>

	<?php echo $__env->make('includes.navtop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('main'); ?>


	<div class="clear"></div>
	<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	


	<?php echo $__env->yieldContent('javascript'); ?>


</body>
</html>
