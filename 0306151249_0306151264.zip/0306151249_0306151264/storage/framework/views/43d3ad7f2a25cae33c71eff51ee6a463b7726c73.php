 <div style="width: auto;height: 33px; margin-left: 8%;"><a href="#">       <div style="height: 35px; width: auto;">
                                    <div class="cl-div-avt-rep-cmt" >
                                        <img class="imgaccountrepcmt"  src=" <?php echo e(asset('pictures/avt1.jpg')); ?>" alt="Mountain View" >
                                    </div>
                                    <div class="cl-div-tare-read-repcmt" >

                                        <div style="width: auto;float: left;height: auto;padding-right: 5px;">
                                                 <textarea cols="47" class="tara-read-cmtrep" > Lu Lu: Không thể asd asd    </textarea>
                                        </div>
                                        <div class="div-btn-show-allcmt" id="div-btn-showcmt-157"  onclick="showfullcmt()" >      
                                                <i style="color: #c5cfd6;" class="fa fa-ellipsis-h stick-xemthem" aria-hidden="true"></i>
                                        </div>
                                        <div class="div-btn-like-cmt" >      
                                                <i style="color: #9695d8;" class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                                        </div>
                                        <div class="div-btn-rep-cmt" >      
                                                <i style="color: #9695d8;" class="fa fa-reply" aria-hidden="true"></i>
                                        </div>
                                        
                                       
                                        
                                    </div>
                                    
                                 </div>       
  </div>