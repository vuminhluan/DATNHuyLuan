<?php $__env->startSection('title'); ?>
	<title>Trang chủ</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="css/trangchu.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	
	
	<div class="home-alert <?php echo e(session('success_message') ? 'alert-animate' : ''); ?>">
		<div class="message baomoi">
			<p class="baomoi">Thông báo: <?php echo e(session('success_message')); ?></p>
		</div>
	</div>
	

	<h1 class="haha">
		<p>Trang chủ</p>
	</h1>
	


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>