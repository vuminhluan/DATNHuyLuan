
<!-- nav top -->
<head>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/includescss/navtopcss.css')); ?>">
  <script src="<?php echo e(asset('js/includesjs/navtopjs.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
</head>
<div class="topnavroot">
  <?php echo csrf_field(); ?>
  <div class="topnav" >
    
    <nav class="navtop-menu">

      
      
      <ul class="navtop-left">
        <li style="width: 150px;border-right: solid 1px #9695d8;height: 48px;margin-left: 30px;">
          <a class="active" href="<?php echo e(route('trangchu')); ?>">Trang chủ</a>
        </li>
        <li><a href="#news">xxxxxxx</a></li>
        <li><a href="#contact">xxxxxxx</a></li>
      </ul>
      

      
      <ul class="navtop-right">
        <li class="search-container">
          <form action="/action_page.php">
            <input id="topnav-search"  type="text" placeholder="Search.." name="search">
            <button type="submit"><i class="fa fa-search"></i></button>
          </form>
        </li>
        
        <li><button id="btn-show-dynamic-menu"><i class="fa fa-bars" aria-hidden="true"></i></button></li>
        

        <?php if(Auth::check()): ?>
        <li class="taikhoan-dropdown-content">
          <a  href="#about"  title="<?php echo e(Auth::user()->ho_ten_lot." ".Auth::user()->ten); ?>">
            <img src="<?php echo e(asset('pictures/anh_dai_dien/'.Auth::user()->anh_dai_dien)); ?>" alt="">
          </a>
          <ul class="taikhoan-dropdown-menu">
            <li>
              <a href="<?php echo e(route('trangcanhan.index', Auth::user()->ten_tai_khoan)); ?>">
                <h3><?php echo e(Auth::user()->ho_ten_lot." ".Auth::user()->ten); ?></h3>
                <p><?php echo e('@'.Auth::user()->ten_tai_khoan); ?></p>
              </a>
            </li>
            <li>
              <a href="<?php echo e(route('caidat.index')); ?>"><i class="fa fa-cogs"></i> Cài đặt</a>
              <a href="<?php echo e(route('lienhe')); ?>"><i class="fa fa-envelope"></i> Liên hệ</a>
            </li>
            <li>
              <a href="<?php echo e(route('dangxuat')); ?>"><i class="fa fa-sign-out"></i> Đăng xuất</a>
              
            </li>
          </ul>
        </li>
        <li><input type="hidden" id="session-ma-tk" value="<?php echo e(Auth::user()->ma_tai_khoan); ?>"></li>
        <?php endif; ?>
      </ul>
      

    </nav>
  </div>
</div>






<div id="div-dynamic-menu" class="modal">

  <!-- Modal content -->
 

</div>

<script>
  // alert($('#session-ma-tk').val());
</script>

