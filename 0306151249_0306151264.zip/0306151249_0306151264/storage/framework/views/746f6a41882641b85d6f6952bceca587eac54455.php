<?php $__env->startSection('title'); ?>
	<title>Trang cá nhân <?php echo e('@'.$taikhoan->ten_tai_khoan); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung_trangcanhan'); ?>
<div class="content">
	Bài viết ở đây (Theo tứ tự mới nhất -> cũ)
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('trang_canhan_javascript'); ?>
	<script>

		$(document).ready(function() {

			if($('#upload-pho-to-message').html() != "") {
				// $('.photo-modal').css('display', 'block');
				$('.photo-modal').addClass('photo-modal-show');
			}

			$('#close-icon').click(function() {
				// $('#upload-pho-to-message').html('');
				$('.photo-modal').removeClass('photo-modal-show');
				// alert('haha');
				// alert('haiz');
			});




		});

	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.luan.trangcanhan_masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>