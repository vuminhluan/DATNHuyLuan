 <head>
   <script src=" <?php echo e(asset('js/includesjs/content-menu-popupjs.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
   <script src="<?php echo e(asset('js/includesjs/content-setting-group-popupjs.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dynamic-menu/dynamic-menucss.css')); ?>">
 </head>

 <div style="height: 500px;width: 700px;background-color: white; margin: auto;border:solid 1px #9695d8;border-radius: 20px;">

 
            <div  style="width: 100%;height: 100%;margin-top: 17px; padding-left: 20px;padding-right: 20px;" >
                  <div class="tab">
                  <button class="tablinks active" onclick="openCity(event, 'divthongbaonhom')"><i class="fa fa-users" aria-hidden="true"></i>&nbsp;Thông báo</button>
                  <button class="tablinks" onclick="openCity(event, 'divpheduyetthanhvien'),opentab_pheduyetthanhvien('<?php echo e($t); ?>')"><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;Phê duyệt thành viên</button>
                  <button class="tablinks" onclick="openCity(event, 'divpheduyetbaiviet')"><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;Phê duyệt bài viết</button>
                  <button class="tablinks" onclick="openCity(event, 'divbaocao')"><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;Báo cáo</button>
                  <button class="tablinks" onclick="openCity(event, 'divcaidatnhom')"><i class="fa fa-cog" aria-hidden="true"></i>&nbsp;Cài đặt</button>
                  
                  </div>

                <div id="divthongbaonhom" style="display: block;" class="tabcontent ">
                  <h3>Thông báo nhóm</h3>
                
                 <div id="div-big-content-menu-nhom"> 
                </div>
              </div>




                <div id="divpheduyetthanhvien" class="tabcontent">
                    
                </div>
                <div id="divpheduyetbaiviet" class="tabcontent">
                  <h3>Phê duyệt bài viết</h3>  
                </div>
                <div id="divbaocao" class="tabcontent">
                  <h3>Báo cáo vi phạm</h3>  
                </div>
                <div id="divcaidatnhom" class="tabcontent">
                  <h3>Cài đặt nhóm</h3>
                </div>
            </div>



  </div>