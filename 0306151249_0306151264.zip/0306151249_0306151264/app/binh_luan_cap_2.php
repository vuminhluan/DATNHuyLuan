<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class binh_luan_cap_2 extends Model
{
    protected $table = "binh_luan_cap_2";
    public $timestamps = false;
}
