<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class thanh_vien_cho_phe_duyet extends Model
{
    protected $table ="thanh_vien_cho_phe_duyet";
    public $timestamps = false;
}
