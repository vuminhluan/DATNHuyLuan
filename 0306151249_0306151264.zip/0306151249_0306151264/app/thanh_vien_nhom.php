<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class thanh_vien_nhom extends Model
{
    protected $table = "thanh_vien_nhom";
    public $timestamps = false;

}
