var link_host = "/DATNHuyLuan/0306151249_0306151264/public";

var myregex = {
	'sodienthoai' : '^[0-9]{9,11}$',
	'matkhau'     : '^[a-z0-9_]{6,30}$',
	'ten_taikhoan': '^[a-z0-9_]{6,40}$',
	'tiengviet'   :'^([A-Za-zÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠ-ỹ]{1,10}((\\s[A-Za-zÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠ-ỹ]{1,15})?)+$)'
};

// console.log(myregex['matkhau']);

